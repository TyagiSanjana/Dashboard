export const navItems = [
  {
    name: 'Home',
    url: '/dashboard',
    icon: 'fa fa-bank',
    /* badge: {
      variant: 'info',
      text: 'NEW'
    } */
  },
  /* {
    name: 'Themes/Colors',
    url: '/theme/colors',
    icon: 'icon-drop'
  },
  {
    name: 'Headings',
    url: '/theme/typography',
    icon: 'icon-pencil'
  }, */
 
  {
    name: 'Reports',
    url: '/base',
    icon: ' fa fa-bar-chart',
    children: [
      {
        name: 'Enhancing and Sustaining Tickets',
        url: '/base/enhancing',
        icon: 'fa fa-neuter'
      },
      {
        name: 'Funding Needing Tickets',
        url: '/base/funding',
        icon: 'fa fa-neuter'
      },
      {
        name: 'Rejected Tickets',
        url: '/base/rejectedtickets',
        icon: 'fa fa-neuter'
      },
      {
        name: 'PMT Related Requests',
        url: '/base/pmtrelatedtickets',
        icon: 'fa fa-neuter'
      },
      {
        name: 'Approved and Cancelled Tickets',
        url: '/base/approvedtickets',
        icon: 'fa fa-neuter'
      },
      {
        name: 'Cancelled Tickets(Enhancing & Sustaining)',
        url: '/cancelledtickets/cancelledtickets',
        icon: 'fa fa-neuter'
      },
      {
        name: 'Open/Closed Tickets',
        url: '/base/open&closedtickets',
        icon: 'fa fa-neuter'
      },
      {
        name: 'Planned Ticket Closure',
        url: '/base/plannedticketclosure',
        icon: 'fa fa-neuter'
      },
      {
        name: 'Requests',
        url: '/base/requests',
        icon: 'fa fa-neuter'
      },
      {
        name: 'Release dates',
        url: '/base/releasedates',
        icon: 'fa fa-neuter'
      },
      {
        name: 'Upcoming Releases',
        url: '/base/upcomingreleases',
        icon: 'fa fa-neuter'
      },
      {
        name: 'Active Requests',
        url: '/base/activerequests',
        icon: 'fa fa-neuter'
      },
      {
        name: 'First Client Communication',
        url: '/base/firstclientcommunication',
        icon: 'fa fa-neuter'
      },
      {
        name: 'Total Closed Tickets',
        url: '/base/totalclosedtickets',
        icon: ' fa fa-neuter'
      }
    ]
  },
 
  {
    name: 'Bold Ticket Dashboard',
    url: '/theme/boldticketdashboard',
    icon: 'fa fa-keyboard-o'
    
    /* class: 'mt-auto', */
    /* variant: 'success' */
  },
  {
    name: 'Cloud RoadMap',
    url: '/theme/cloudroadmap',
    icon: ' fa fa-pie-chart',
    /* variant: 'danger' */
  },
  {
    name: 'Tool RoadMap',
    url: '/widgets/toolroadmap',
    icon: ' fa fa-wrench',
   /*  variant: 'danger' */
  },
  {
    name: 'Charts',
    url: '/theme/chartjs',
    icon: ' fa fa-area-chart',
   /*  variant: 'danger' */
  }
];

  /* {
    name: 'Icons',
    url: '/icons',
    icon: 'icon-star',
    children: [
      {
        name: 'CoreUI Icons',
        url: '/icons/coreui-icons',
        icon: 'icon-star',
        badge: {
          variant: 'success',
          text: 'NEW'
        }
      },
      {
        name: 'Flags',
        url: '/icons/flags',
        icon: 'icon-star'
      },
      {
        name: 'Font Awesome',
        url: '/icons/font-awesome',
        icon: 'icon-star',
        badge: {
          variant: 'secondary',
          text: '4.7'
        }
      },
      {
        name: 'Simple Line Icons',
        url: '/icons/simple-line-icons',
        icon: 'icon-star'
      }
    ]
  }, */
/*   {
    name: 'Notifications',
    url: '/notifications',
    icon: 'icon-bell',
    children: [
      {
        name: 'Alerts',
        url: '/notifications/alerts',
        icon: 'icon-bell'
      },
      {
        name: 'Badges',
        url: '/notifications/badges',
        icon: 'icon-bell'
      },
      {
        name: 'Modals',
        url: '/notifications/modals',
        icon: 'icon-bell'
      }
    ]
  }, */
  /* {
    name: 'Widgets',
    url: '/widgets',
    icon: 'icon-calculator',
    badge: {
      variant: 'info',
      text: 'NEW'
    }
  },
  {
    divider: true
  },
  {
    title: true,
    name: 'Extras',
  }, */
/*   {
    name: 'Pages',
    url: '/pages',
    icon: 'icon-star',
    children: [
      {
        name: 'Login',
        url: '/login',
        icon: 'icon-star'
      },
      {
        name: 'Register',
        url: '/register',
        icon: 'icon-star'
      },
      {
        name: 'Error 404',
        url: '/404',
        icon: 'icon-star'
      },
      {
        name: 'Error 500',
        url: '/500',
        icon: 'icon-star'
      }
    ]
  }, */
   /* {
    name: 'Bold Ticket Dashboard',
    url: '/buttons',
    icon: 'icon-cursor',
    children: [
      {
        name: 'Buttons',
        url: '/buttons/buttons',
        icon: 'icon-cursor'
      },
      {
        name: 'Dropdowns',
        url: '/buttons/dropdowns',
        icon: 'icon-cursor'
      },
      {
        name: 'Brand Buttons',
        url: '/buttons/brand-buttons',
        icon: 'icon-cursor'
      }
    ]
  }, */
 /*  {
    name: 'Bold Ticket Dashboard',
    url: '/charts',
    icon: 'icon-pie-chart'
  }, */
