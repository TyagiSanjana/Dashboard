// Angular
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { BoldTicketComponent } from './boldticketdashboard.component';
import { CloudRoadMapComponent } from './cloudroadmap.component';

// Theme Routing
import { ThemeRoutingModule } from './theme-routing.module';
import { ChartJSComponent } from './chartjs.component';
import { ChartsModule } from 'ng2-charts/ng2-charts';



@NgModule({
  imports: [
    CommonModule,
    ThemeRoutingModule,
    ChartsModule
  ],
  declarations: [
    BoldTicketComponent,
    CloudRoadMapComponent,
    ChartJSComponent
  ]
})
export class ThemeModule { }
