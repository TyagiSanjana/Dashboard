import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  templateUrl: 'chartjs.component.html'
})
export class ChartJSComponent {

  constructor (private httpService: HttpClient) { }
  // barChart
  public barChartOptions: any = {
    scaleShowVerticalLines: false,
    responsive: true
  };
  public barChartLabels: string[] = ['2006', '2007', '2008', '2009', '2010', '2011', '2012','2013','2014','2015'];
  public barChartType = 'bar';
  public barChartLegend = true;


  public barChartData : any[]= [
    {
      label: '1st Year',
      data: [], 
    },
    { 
      label: '2nd Year',
      data: []
    }
   ];
  ngOnInit () {
    this.httpService.get('./assets/data.json', {responseType: 'json'}).subscribe(
    data => {
        this.barChartData = data as any [];	 // FILL THE CHART ARRAY WITH DATA.
    },
    (err: HttpErrorResponse) => {
        console.log (err.message);
    }
    );
}

  // events
  public chartClicked(e: any): void {
    console.log(e);
  }

  public chartHovered(e: any): void {
    console.log(e);
  }

}
