import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BoldTicketComponent } from './boldticketdashboard.component';
import { CloudRoadMapComponent } from './cloudroadmap.component';
import { ChartJSComponent } from './chartjs.component';
import { ChartsModule } from 'ng2-charts/ng2-charts';


const routes: Routes = [
  {
    path: '',
    data: {
      //title: ''
    },
    children: [
      {
        path: 'boldticketdashboard',
        component: BoldTicketComponent,
        data: {
          title: 'BOLD Ticket Dashboard'
        }
      },
      {
        path: 'cloudroadmap',
        component: CloudRoadMapComponent,
        data: {
          title: 'Cloud RoadMap'
        }
      },
      {
        path: 'chartjs',
        component: ChartJSComponent,
        data: {
          title: 'Charts'
        }
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ThemeRoutingModule {}
