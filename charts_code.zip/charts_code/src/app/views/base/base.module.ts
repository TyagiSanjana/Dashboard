// Angular
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';

import { OpenClosedTicketsComponent } from './open&closedtickets.component';
import {PlannedTicketClosureComponent} from './plannedticketclosure.component';

// Forms Component
import { PMTRelatedTicketsComponent } from './PMTrelatedtickets.component';

import { UpcomingReleasesComponent } from './upcomingreleases.component';
import { ActiveRequestComponent } from './activerequests.component';
// Tabs Component
import { TabsModule } from 'ngx-bootstrap/tabs';
import { FirstClientCommunicationComponent } from './firstclientcommunication.component';

// Carousel Component
import { CarouselModule } from 'ngx-bootstrap/carousel';
import { FundingComponent } from './funding.component';

// Collapse Component
import { CollapseModule } from 'ngx-bootstrap/collapse';
import { RejectedTicketsComponent } from './rejectedtickets.component';

// Dropdowns Component
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';

// Pagination Component
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { RequestsComponent } from './requests.component';

// Popover Component
import { PopoverModule } from 'ngx-bootstrap/popover';
import { ApprovedTicketsComponent } from './approvedtickets.component';

// Progress Component
import { ProgressbarModule } from 'ngx-bootstrap/progressbar';
import { ReleaseDatesComponent } from './releasedates.component';

// Tooltip Component
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { TotalClosedTicketsComponent } from './totalclosedtickets.component';


// Components Routing
import { BaseRoutingModule } from './base-routing.module';
import { EnhancingComponent} from './enhancing.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    BaseRoutingModule,
    BsDropdownModule.forRoot(),
    TabsModule,
    CarouselModule.forRoot(),
    CollapseModule.forRoot(),
    PaginationModule.forRoot(),
    PopoverModule.forRoot(),
    ProgressbarModule.forRoot(),
    TooltipModule.forRoot()
  ],
  declarations: [
    OpenClosedTicketsComponent,
    PMTRelatedTicketsComponent,
    UpcomingReleasesComponent,
    ActiveRequestComponent,
    FirstClientCommunicationComponent,
  FundingComponent,
    RejectedTicketsComponent,
    ApprovedTicketsComponent,
    RequestsComponent,
    ReleaseDatesComponent,
    TotalClosedTicketsComponent,
    PlannedTicketClosureComponent,
    EnhancingComponent
  ]
})
export class BaseModule { }
