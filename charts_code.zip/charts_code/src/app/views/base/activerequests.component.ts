import { Component } from '@angular/core';

@Component({
  templateUrl: 'activerequests.component.html'
})
export class ActiveRequestComponent {

  constructor() { }

}
