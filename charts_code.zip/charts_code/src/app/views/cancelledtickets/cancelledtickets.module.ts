import { NgModule } from '@angular/core';

import { CancelledTicketsComponent } from './cancelledtickets.component';
import { FlagsComponent } from './flags.component';
import { FontAwesomeComponent } from './font-awesome.component';
import { SimpleLineIconsComponent } from './simple-line-icons.component';

import { IconsRoutingModule } from './cancelledtickets-routing.module';

@NgModule({
  imports: [ IconsRoutingModule ],
  declarations: [
    CancelledTicketsComponent,
    FlagsComponent,
    FontAwesomeComponent,
    SimpleLineIconsComponent
  ]
})
export class CancelledTicketsModule { }
