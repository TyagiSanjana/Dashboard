// Angular
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { BoldTicketComponent } from './boldticketdashboard.component';
import { CloudRoadMapComponent } from './cloudroadmap.component';

// Theme Routing
import { ThemeRoutingModule } from './theme-routing.module';

@NgModule({
  imports: [
    CommonModule,
    ThemeRoutingModule
  ],
  declarations: [
    BoldTicketComponent,
    CloudRoadMapComponent
  ]
})
export class ThemeModule { }
