import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { BoldTicketComponent } from './boldticketdashboard.component';
import { CloudRoadMapComponent } from './cloudroadmap.component';

const routes: Routes = [
  {
    path: '',
    data: {
      //title: ''
    },
    children: [
      {
        path: 'boldticketdashboard',
        component: BoldTicketComponent,
        data: {
          title: 'BOLD Ticket Dashboard'
        }
      },
      {
        path: 'cloudroadmap',
        component: CloudRoadMapComponent,
        data: {
          title: 'Cloud RoadMap'
        }
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ThemeRoutingModule {}
