import { Component } from '@angular/core';

@Component({
  templateUrl: 'cloudroadmap.component.html'
})
export class CloudRoadMapComponent {

  constructor() { }

}
