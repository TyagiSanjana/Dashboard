import { Component } from '@angular/core';

@Component({
  templateUrl: 'open&closedtickets.component.html'
})
export class OpenClosedTicketsComponent {

  constructor() { }

}
