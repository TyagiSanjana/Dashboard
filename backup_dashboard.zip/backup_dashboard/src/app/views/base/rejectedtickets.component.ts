import { Component } from '@angular/core';

@Component({
  templateUrl: 'rejectedtickets.component.html'
})
export class RejectedTicketsComponent {

  constructor() { }

  isCollapsed: boolean = false;

  collapsed(event: any): void {
    // console.log(event);
  }

  expanded(event: any): void {
    // console.log(event);
  }

}
