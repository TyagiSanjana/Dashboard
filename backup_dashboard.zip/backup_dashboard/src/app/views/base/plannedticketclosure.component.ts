import { Component } from '@angular/core';

@Component({
  templateUrl: 'plannedticketclosure.component.html'
})
export class PlannedTicketClosureComponent {

  constructor() { }

}
