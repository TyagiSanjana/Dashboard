import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { OpenClosedTicketsComponent } from './open&closedtickets.component';
import { PMTRelatedTicketsComponent } from './PMTrelatedtickets.component';
import { UpcomingReleasesComponent } from './upcomingreleases.component';
import { ActiveRequestComponent } from './activerequests.component';
import { FirstClientCommunicationComponent } from './firstclientcommunication.component';
import { FundingComponent } from './funding.component';
import { RejectedTicketsComponent } from './rejectedtickets.component';
import { ApprovedTicketsComponent } from './approvedtickets.component';
import {RequestsComponent} from './requests.component';
import {ReleaseDatesComponent} from './releasedates.component';
import {TotalClosedTicketsComponent} from './totalclosedtickets.component';
import {PlannedTicketClosureComponent} from './plannedticketclosure.component';
import { EnhancingComponent} from './enhancing.component';

const routes: Routes = [
  {
    path: '',
    data: {
      title: 'Reports'
    },
    children: [
      {
        path: 'open&closedtickets',
        component: OpenClosedTicketsComponent,
        data: {
          title: 'Open/Closed Tickets'
        }
      },
      {
        path: 'pmtrelatedtickets',
        component: PMTRelatedTicketsComponent,
        data: {
          title: 'PMT Related Requests'
        }
      },
      {
        path: 'upcomingreleases',
        component: UpcomingReleasesComponent,
        data: {
          title: 'Upcoming Releases'
        }
      },
      {
        path: 'activerequests',
        component: ActiveRequestComponent,
        data: {
          title: 'Active Requests'
        }
      },
      {
        path: 'firstclientcommunication',
        component: FirstClientCommunicationComponent ,
        data: {
          title: 'First Client Communication'
        }
      },
      {
        path: 'funding',
        component: FundingComponent,
        data: {
          title: 'Funding needing Tickets'
        }
      },
      {
        path: 'rejectedtickets',
        component: RejectedTicketsComponent,
        data: {
          title: 'Rejected Tickets'
        }
      },
      {
        path: 'approvedtickets',
        component: ApprovedTicketsComponent,
        data: {
          title: 'Approved & Cancelled Tickets'
        }
      },
      {
        path: 'requests',
        component: RequestsComponent,
        data: {
          title: 'Requests'
        }
      },
      {
        path: 'releasedates',
        component: ReleaseDatesComponent,
        data: {
          title: 'Release Dates'
        }
      },
      {
        path: 'totalclosedtickets',
        component: TotalClosedTicketsComponent,
        data: {
          title: 'Total Closed Tickets'
        }
      }, {
        path: 'plannedticketclosure',
        component: PlannedTicketClosureComponent,
        data: {
          title: 'Planned Ticket Closure'
        }
      
      }
      , {
        path: 'enhancing',
        component: EnhancingComponent,
        data: {
          title: 'Enhancing and Sustaining Tickets'
        }
      
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BaseRoutingModule {}
