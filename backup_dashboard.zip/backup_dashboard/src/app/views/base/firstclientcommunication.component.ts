import { Component } from '@angular/core';

@Component({
  templateUrl: 'firstclientcommunication.component.html'
})
export class FirstClientCommunicationComponent {

  constructor() { }

}
