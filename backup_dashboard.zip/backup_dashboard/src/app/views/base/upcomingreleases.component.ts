import { Component } from '@angular/core';

@Component({
  templateUrl: 'upcomingreleases.component.html'
})
export class UpcomingReleasesComponent {

  constructor() { }

}
