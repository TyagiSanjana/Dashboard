import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ToolRoadMapComponent } from './toolroadmap.component';

const routes: Routes = [
  {
    path: 'toolroadmap',
    component: ToolRoadMapComponent,
    data: {
      title: 'Tool Road Map'
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class WidgetsRoutingModule {}
