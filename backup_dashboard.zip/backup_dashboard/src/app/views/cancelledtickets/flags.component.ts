import { Component } from '@angular/core';

@Component({
  templateUrl: 'flags.component.html'
})
export class FlagsComponent {

  constructor() { }

}
