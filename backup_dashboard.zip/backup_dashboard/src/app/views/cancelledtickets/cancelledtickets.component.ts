import { Component } from '@angular/core';

@Component({
  templateUrl: 'cancelledtickets.component.html'
})
export class CancelledTicketsComponent {

  constructor() { }

}
